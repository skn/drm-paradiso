/*
 ***************************************************************************
 * Ralink Tech Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 2002-2004, Ralink Technology, Inc.
 *
 * This program is free software; you can redistribute it and/or modify  * 
 * it under the terms of the GNU General Public License as published by  * 
 * the Free Software Foundation; either version 2 of the License, or     * 
 * (at your option) any later version.                                   * 
 *                                                                       * 
 * This program is distributed in the hope that it will be useful,       * 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        * 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         * 
 * GNU General Public License for more details.                          * 
 *                                                                       * 
 * You should have received a copy of the GNU General Public License     * 
 * along with this program; if not, write to the                         * 
 * Free Software Foundation, Inc.,                                       * 
 * 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             * 
 *                                                                       * 
 ************************************************************************
	Module Name:
	wpa.h

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
	Name		Date			Modification logs
	Jan Lee		2005-06-01		Release
*/

#ifndef __WPA_H__
#define __WPA_H__

//Messages for the wpa state machine,
#define WPA_MACHINE_BASE            21
#define EAP_MSG_TYPE_EAPPacket      21
#define EAP_MSG_TYPE_EAPOLStart     22
#define EAP_MSG_TYPE_EAPOLLogoff    23
#define EAP_MSG_TYPE_EAPOLKey       24
#define EAP_MSG_TYPE_EAPOLASFAlert  25
#define MAX_WPA_PSK_MSG             5

// WpaPsk EAPOL Key descripter frame format related length
#define LEN_KEY_DESC_NONCE          32
#define LEN_KEY_DESC_IV             16
#define LEN_KEY_DESC_RSC            8
#define LEN_KEY_DESC_ID             8
#define LEN_KEY_DESC_REPLAY         8
#define LEN_KEY_DESC_MIC            16

//EPA VERSION
#define EAPOL_VER                   1
#define DESC_TYPE_TKIP              1
#define DESC_TYPE_AES               2
#define RSN_KEY_DESC                0xfe
#define WPA1_KEY_DESC		0xFE
#define WPA2_KEY_DESC		0x2


#define LEN_MASTER_KEY              32  

// EAPOL EK, MK
#define LEN_EAP_EK                  16
#define LEN_EAP_MICK                16
#define LEN_EAP_KEY                 ((LEN_EAP_EK)+(LEN_EAP_MICK))
// TKIP key related
#define LEN_TKIP_EK                 16
#define LEN_TKIP_RXMICK             8
#define LEN_TKIP_TXMICK             8
#define LEN_AES_EK                  16
#define LEN_AES_KEY                 LEN_AES_EK
#define LEN_TKIP_KEY                ((LEN_TKIP_EK)+(LEN_TKIP_RXMICK)+(LEN_TKIP_TXMICK))
#define TKIP_AP_TXMICK_OFFSET       ((LEN_EAP_KEY)+(LEN_TKIP_EK))
#define TKIP_AP_RXMICK_OFFSET       (TKIP_AP_TXMICK_OFFSET+LEN_TKIP_TXMICK)
#define TKIP_GTK_LENGTH             ((LEN_TKIP_EK)+(LEN_TKIP_RXMICK)+(LEN_TKIP_TXMICK))
#define LEN_PTK                     ((LEN_EAP_KEY)+(LEN_TKIP_KEY))
#define MAX_LEN_OF_RSNIE            48

//EAP Packet Type
#define EAPPacket       0
#define EAPOLStart      1
#define EAPOLLogoff     2
#define EAPOLKey        3
#define EAPOLASFAlert   4
#define EAPTtypeMax     5

#define EAPOL_MSG_INVALID   0
#define EAPOL_PAIR_MSG_1    1
#define EAPOL_PAIR_MSG_3    2
#define EAPOL_GROUP_MSG_1   3

// EAPOL Key Information definition within Key descriptor format
struct _KEY_INFO
{
    UCHAR   KeyMic:1;
    UCHAR   Secure:1;
    UCHAR   Error:1;
    UCHAR   Request:1;
    UCHAR   EKD:1;
    UCHAR   Rsvd:3;
    UCHAR   KeyDescVer:3;
    UCHAR   KeyType:1;
    UCHAR   KeyIndex:2;
    UCHAR   Install:1;
    UCHAR   KeyAck:1;
}    __attribute__((__packed__));
typedef struct _KEY_INFO
 KEY_INFO;
typedef struct _KEY_INFO
 *PKEY_INFO;


// EAPOL Key descriptor format
struct  _KEY_DESCRIPTER
{
    UCHAR       Type;
    KEY_INFO    KeyInfo;
    UCHAR       KeyLength[2];
    UCHAR       ReplayCounter[LEN_KEY_DESC_REPLAY];
    UCHAR       KeyNonce[LEN_KEY_DESC_NONCE];
    UCHAR       KeyIv[LEN_KEY_DESC_IV];
    UCHAR       KeyRsc[LEN_KEY_DESC_RSC];
    UCHAR       KeyId[LEN_KEY_DESC_ID];
    UCHAR       KeyMic[LEN_KEY_DESC_MIC];
    UCHAR       KeyDataLen[2];     
    UCHAR       KeyData[MAX_LEN_OF_RSNIE];
}    __attribute__((__packed__));
typedef struct _KEY_DESCRIPTER
 KEY_DESCRIPTER;
typedef struct _KEY_DESCRIPTER
 *PKEY_DESCRIPTER;


struct  _EAPOL_PACKET
{
    UCHAR               Version;
    UCHAR               Type;
    UCHAR               Len[2];
    KEY_DESCRIPTER      KeyDesc;
}    __attribute__((__packed__));
typedef struct _EAPOL_PACKET
 EAPOL_PACKET;
typedef struct _EAPOL_PACKET
 *PEAPOL_PACKET;


//802.11i D10 page 83
struct  _GTK_ENCAP
{
    UCHAR               Kid:2;
    UCHAR               tx:1;
    UCHAR               rsv:5;
    UCHAR               rsv1;
    UCHAR               GTK[32];
}    __attribute__((__packed__));
typedef struct _GTK_ENCAP
 GTK_ENCAP;
typedef struct _GTK_ENCAP
 *PGTK_ENCAP;

struct  _KDE_ENCAP
{
    UCHAR               Type;
    UCHAR               Len;
    UCHAR               OUI[3];
    UCHAR               DataType;
    GTK_ENCAP      GTKEncap;
}    __attribute__((__packed__));
typedef struct _KDE_ENCAP
 KDE_ENCAP;
typedef struct _KDE_ENCAP
 *PKDE_ENCAP;


// For supplicant state machine states. 802.11i Draft 4.1, p. 97
// We simplified it
typedef enum    _WpaState
{
    SS_NOTUSE,              // 0
    SS_START,               // 1
    SS_WAIT_MSG_3,          // 2
    SS_WAIT_GROUP,          // 3
    SS_FINISH,              // 4
    SS_KEYUPDATE,           // 5
}   WPA_STATE;

#endif
