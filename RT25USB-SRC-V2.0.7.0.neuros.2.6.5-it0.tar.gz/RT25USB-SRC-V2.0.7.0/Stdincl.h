#ifndef _stdincl_h_OK__
#define _stdincl_h_OK__




//=============================================
// functions in usbrx.c
//=============================================

int USB_RxPacket(PRT2570ADAPTER Adapter);

//=============================================
// functions in rt2570_main.c
//=============================================

VOID ReleaseAdapter(PRT2570ADAPTER   Adapter, BOOLEAN IsFree);


VOID RejectPendingPackets(PRT2570ADAPTER Adapter);

int ControlThread(IN OUT PVOID Context);


int TXThread(IN OUT PVOID  Context);


BOOLEAN RT2570UsbReset(PRT2570ADAPTER    Adapter);

NTSTATUS USB_ResetPipe(PRT2570ADAPTER    Adapter, 
                       UINT BulkPipe);

int USB_CallUSBD(PRT2570ADAPTER Adapter, 
                      IN PURB       Urb);
#endif

